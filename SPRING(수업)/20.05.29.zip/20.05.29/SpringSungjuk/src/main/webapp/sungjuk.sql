create table sungjuk (
  hakbun varchar2(10),
  irum varchar2(15),
  kor number(3),
  eng number(3),
  math number(3),
  tot number(3),
  avg number(5,2),
  grade varchar2(5),
  primary key(hakbun)
);