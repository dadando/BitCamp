package GoodsEx;

import Mbc.GoodsStock;

public class ClassExample1 {

	public static void main(String[] args) {
		GoodsStock obj;
		obj = new GoodsStock();
		obj.setGoodsCode("52135");
		obj.setStockNum(200);
		System.out.println("��ǰ�ڵ�: "+obj.getGoodsCode());
		System.out.println("�������: "+obj.getStockNum());
		obj.addStock(1000);
		System.out.println("��ǰ�ڵ�: "+obj.getGoodsCode());
		System.out.println("�������: "+obj.getStockNum());

	}

}
