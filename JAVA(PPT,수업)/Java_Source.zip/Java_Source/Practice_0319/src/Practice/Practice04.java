package Practice;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Practice04 {

	public static void main(String[] args) {
		// TODO StringTokenizer�� �̿��� 369
		Scanner scan = new Scanner(System.in);
		System.out.println("## ���� �Է� ##");
		String num = scan.nextLine();
		StringTokenizer st = new StringTokenizer(num);
		
		while(st.hasMoreTokens()) {
			String ch = st.nextToken();
			int num2 = Integer.parseInt(ch);
			//System.out.println(ch);
			if(num2%3==0) {
				System.out.println("¦");
			}else {
				System.out.println(num2);
			}
		}
	}
}
