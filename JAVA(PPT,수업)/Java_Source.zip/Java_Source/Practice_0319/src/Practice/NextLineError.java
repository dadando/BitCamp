package Practice;

import java.util.Scanner;

public class NextLineError {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        
        System.out.print("ù��° �����Է�: ");
        int i = scanner.nextInt();
        System.out.println(i);
        scanner.nextLine();
        System.out.print("ù��° ���ڿ��Է�: ");
        String str1 = scanner.nextLine();
        System.out.println(str1);
        
        System.out.print("�ι�° �����Է�: ");
        int j = scanner.nextInt();
        System.out.println(i);
        
        System.out.print("�ι�° ���ڿ��Է�: ");
        String str2 = scanner.next();
        System.out.println(str2);



	}

}
