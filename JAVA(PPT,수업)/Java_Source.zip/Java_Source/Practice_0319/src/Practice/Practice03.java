package Practice;

import java.util.StringTokenizer;

public class Practice03 {

	public static void main(String[] args) {
		// TODO StringTokenizer �޼ҵ�
		StringTokenizer tokstr = new StringTokenizer("���,��,������",",");
		while(tokstr.hasMoreTokens()) {
			String str = tokstr.nextToken();
			System.out.println(str);
		}
		System.out.println("=========");
		StringTokenizer tokstr2 = new StringTokenizer("���,��,������",",",true);
		while(tokstr2.hasMoreTokens()) {
			String str2 = tokstr2.nextToken();
			System.out.println(str2);
		}
	}

}
