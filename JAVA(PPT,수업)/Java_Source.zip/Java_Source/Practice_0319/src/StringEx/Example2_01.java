package StringEx;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Example2_01 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int result;
		String str = null, token_str = null;
		
	input_loop:
		while(true) {
			System.out.print("���� �Է�=> ");
			str = scan.next().trim();
			
			StringTokenizer token = new StringTokenizer(str,"+-*/",true);
			
			token_str = token.nextToken();
			
			if(input_check(token_str)) {
				System.out.println("���� �Է� ����!!\n");
				continue;
			}
			
			result = Integer.parseInt(token_str);
			
			while(token.hasMoreTokens()) {
				token_str = token.nextToken();
				char ch = token.toString().charAt(0);
				
				if(token.hasMoreTokens()) {
					token_str = token.nextToken();
				}else{
					System.out.println("���� �Է� ����!!!\n");
					continue input_loop;
				}
				if(input_check(token_str)) {
					System.out.println("���� �Է� ����!!!\n");
					continue input_loop;
				}
				
				switch(ch) {
				case '+':
					result += Integer.parseInt(token_str);
					break;
				case '-':
					result -= Integer.parseInt(token_str);
					break;
				case '*':
					result *= Integer.parseInt(token_str);
					break;
				case '/':
					result /= Integer.parseInt(token_str);
					break;
				}
				
			}
			break;
		}
		System.out.println(str+"="+result);
	}
	
	static boolean input_check(String str) {
		char ch;
		
		for(int i=0;i<str.length();i++) {
			ch = str.charAt(i);
			
			if(ch<'0' || ch>'9')
				return true;
		}
		return false;
	}
}
