package StringEx;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Example2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int num = 0;
		
		System.out.print("�����Է�=> ");
		String str = scan.next().trim();
		
		StringTokenizer stok = new StringTokenizer(str,"+-/*",true);
		num+=Integer.parseInt(stok.nextToken());
		
		while(stok.hasMoreTokens()) {
			char str2 = stok.nextToken().charAt(0);
			if(str2=='+')
				num+=Integer.parseInt(stok.nextToken());
			else if(str2=='-')
				num-=Integer.parseInt(stok.nextToken());
			else if(str2=='/')
				num/=Integer.parseInt(stok.nextToken());
			else if(str2=='*')
				num*=Integer.parseInt(stok.nextToken());
			/*switch(str2) {
			case '+':
				num+=Integer.parseInt(stok.nextToken());
				break;
			case '-':
				num-=Integer.parseInt(stok.nextToken());
				break;
			case '/':
				num/=Integer.parseInt(stok.nextToken());
				break;
			case '*':
				num*=Integer.parseInt(stok.nextToken());
				break;
			}*/
		
		}
		System.out.println(str+" = "+num);
	}

}
