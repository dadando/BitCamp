package StringEx;

import java.util.StringTokenizer;

public class StringTokenizerExample1 {

	public static void main(String[] args) {
		StringTokenizer stok = new StringTokenizer("��,����|������,��","��,|",true);
		while(stok.hasMoreTokens()) {
			String str = stok.nextToken();
			System.out.println(str);
		}

	}

}
