package StringEx;

public class StringExample6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "���� �ڱ��ϴ� �ڹ�";
		System.out.println(str.substring(3));
		System.out.println(str.substring(3,7));
	}

}
