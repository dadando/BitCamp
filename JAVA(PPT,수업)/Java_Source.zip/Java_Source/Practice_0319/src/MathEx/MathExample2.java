package MathEx;

class MathExample2 { 
    public static void main(String args[]) { 
        System.out.println("sin(pi) = " + Math.sin(Math.PI)); 
        System.out.println("cos(pi) = " + Math.cos(Math.PI)); 
        System.out.println("tan(pi) = " + Math.tan(Math.PI)); 
    } 
} 