package RandomEx;

import java.util.Random;

public class Example1 {

	public static void main(String[] args) {
		Random rand = new Random();
		int MAX = 6;
		int RANGE =45;
		int i,j;
		int[] arr = new int[MAX];
		
		
		for(i=0;i<MAX;i++) {
			arr[i] = rand.nextInt(RANGE)+1;
			for(j=0;j<i;j++) {
				if(arr[i]==arr[j]) {
					i--;
					break;
				}
			}
		}
		
		System.out.printf("[ %d, %d, %d, %d, %d, %d ]\n",arr[0],arr[1],arr[2],arr[3],arr[4],arr[5]);
	
	}

}
