package RandomEx;

import java.util.Random;

public class RandomExample2 {
	public static void main(String[] args) {
		Random rand = new Random(56419L);
		System.out.println(rand.nextInt(100));
		System.out.println(rand.nextInt(100));
		System.out.println(rand.nextInt(100));
	}
}
