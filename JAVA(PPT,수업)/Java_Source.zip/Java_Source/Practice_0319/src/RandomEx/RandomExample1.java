package RandomEx;

import java.util.Random;

public class RandomExample1 {

	public static void main(String[] args) {
		Random rand = new Random();
		System.out.println(rand.nextInt(100));
		System.out.println(rand.nextInt(100));
		System.out.println(rand.nextInt(100));

	}

}
