package RandomEx;

import java.util.Random;

public class InsertionEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rand = new Random();
		int MAX = 7;
		int RANGE =45;
		int i,j;
		int[] arr = new int[MAX];
		
		
		for(i=1;i<MAX;i++) {
			arr[i] = rand.nextInt(RANGE)+1;
			for(j=1;j<i;j++) {
				if(arr[i]==arr[j]) {
					i--;
					break;
				}
			}
			
		}
		for(i=1;i<MAX;i++) {
			int key = arr[i];
			for(j=i-1;arr[j]>key;j--) { // ���ǽ��� '>'�̸� �������� '<' �̸� ��������
				arr[j+1] = arr[j];
				if(j==0) {
					break;
				}
			}
			arr[j+1] = key;
		}
		System.out.printf("[ %d, %d, %d, %d, %d, %d ]\n"
				,arr[1],arr[2],arr[3],arr[4],arr[5],arr[6]);
	}

}
