package DivideEx;

public class DivideExample {
	DivideExample(){
		
	}
	void powerOn() {
		
	}
	double divide(int x, int y) {
		return x/y;
	}
}
