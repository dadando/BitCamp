package DivideEx;
public class DivideExample01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DivideExample div = new DivideExample();
		System.out.println(div.divide(10, 20));
	}

}
