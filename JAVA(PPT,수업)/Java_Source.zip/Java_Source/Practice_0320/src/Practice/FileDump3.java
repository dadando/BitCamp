package Practice;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileDump3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*if(args.length<2) {
			System.out.println("Usage: java FileDump <filename>");
			return;
		}*/
		FileReader in =null;
		FileWriter out= null;
		try {
			in = new FileReader("FileDump.java");
			out = new FileWriter("FileDump.java.bak2");
			while(true) {
				int num = in.read();
				if(num<0)
					break;
				out.write((char)num);
			}
		}
		catch(FileNotFoundException fnfe) {
			System.out.println(args[0] + "������ �������� �ʽ��ϴ�.");
		}
		catch(IOException ioe) {
			System.out.println(args[0] + "������ ���� �� �����ϴ�.");
		}
		finally {
			try {
				in.close();
				out.close();
			}
			catch(Exception e) {
				
			}
		}
	}

}
