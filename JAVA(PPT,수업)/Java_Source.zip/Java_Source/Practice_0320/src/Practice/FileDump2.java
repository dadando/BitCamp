package Practice;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileDump2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length<1) {
			System.out.println("Usage: java FileDump <filename>");
			return;
		}
		FileReader in =null;
		try {
			in = new FileReader(args[0]);
			while(true) {
				int num = in.read();
				if(num<0)
					break;
				System.out.printf("%c", (char)num);
			}
		}
		catch(FileNotFoundException fnfe) {
			System.out.println(args[0] + "������ �������� �ʽ��ϴ�.");
		}
		catch(IOException ioe) {
			System.out.println(args[0]+"������ ���� �� �����ϴ�.");
		}
		finally {
			try {
				in.close();
			}
			catch(Exception e) {
				
			}
		}
	}

}
