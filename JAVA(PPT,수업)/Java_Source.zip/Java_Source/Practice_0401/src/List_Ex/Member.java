package List_Ex;

import java.util.Scanner;

public class Member{
	String irum,gender,email,id,passwd;
	
	Member(){
	}
	
	public void inputData() {
		Scanner scan = new Scanner(System.in);
		System.out.print("�̸� �Է�=> ");
		irum = scan.next();
		System.out.print("���� �Է�=> ");
		gender = scan.next();
		System.out.print("�̸��� �Է�=> ");
		email = scan.next();
		System.out.print("���̵� �Է�=> ");
		id = scan.next();
		System.out.print("�н����� �Է�=> ");
		passwd = scan.next();
		System.out.println();
	}
	
	public void outputData() {
		
		System.out.printf("%3s  %6s%10s%10s %10s\n",irum,gender,email,id,passwd);
	}
	
}
