package LinkedListEx;

import java.util.Stack;

public class StackExample1 {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(new Integer(12));
		stack.push(new Integer(59));
		stack.push(new Integer(7));
		while(!stack.isEmpty()) {
			Integer num = stack.pop();
			System.out.println(num);
		}
	}

}
