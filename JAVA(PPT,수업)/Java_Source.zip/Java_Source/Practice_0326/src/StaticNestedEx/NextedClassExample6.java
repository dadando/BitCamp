package StaticNestedEx;

public class NextedClassExample6 {

	public static void main(String[] args) {
		Line.Point point = new Line.Point(100,200);
		System.out.printf("(%d, %d)",point.x,point.y);

	}

}
