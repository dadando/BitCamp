package NestedEx;

import java.util.ArrayList;
import java.util.Scanner;

public class SungjukInner {
	ArrayList<Sungjuk> list = new ArrayList<Sungjuk>();
	
	SungjukInner(){
	}
	
	void addSungjuk() {
		Sungjuk obj = new Sungjuk();
		obj.input();
		if(checkSungjuk(obj)) {
			System.out.println("\n�й� �Է� ����(�ߺ�)!!\n");
			return;
		}
		obj.process();
		list.add(obj);
		System.out.println("\n���� ���� �Է� ����!!\n");
	}
	
	void removeSungjuk(Sungjuk obj) {
		list.remove(obj);
	}
	
	int getSungjukNum() {
		return list.size();
	}
	boolean checkSungjuk(Sungjuk obj) {
		for(Sungjuk dat:list) {
			if(dat.hakbun.equals(obj.hakbun)) {
				return true;
			}
		}
		return false;
	}
	ArrayList<Sungjuk> getList(){
		return list;
	}
	Sungjuk getSungjuk(int index) {
		return list.get(index);
	}
	
	double getTotalAvg() {
		double tot_avg = 0;
		for(Sungjuk obj:list) {
			tot_avg += obj.avg;
		}
		return tot_avg;
	}
	
	class Sungjuk{
		String hakbun, name;
		int kor, eng, math;
		int tot;
		double avg;
		String grade;
		
		public Sungjuk() {
			
		}
		
		void input() {
			Scanner scan = new Scanner(System.in);
			
			System.out.print("�й� �Է�=> ");
			hakbun = scan.next();
			System.out.print("�̸� �Է�=> ");
			name = scan.next();
			System.out.print("���� ����=> ");
			kor = scan.nextInt();
			System.out.print("���� ����=> ");
			eng = scan.nextInt();
			System.out.print("���� ����=> ");
			math = scan.nextInt();
			System.out.println();
			
		}
		void process() {
			tot = kor+eng+math;
			avg = tot/3.;
			switch((int)avg/10) {
			case 10:
			case 9:
				grade = "��";
				break;
			case 8:
				grade = "��";
				break;
			case 7:
				grade = "��";
				break;
			case 6:
				grade = "��";
				break;
			default:
				grade = "��";
					
			}
		}
		void output() {
			System.out.printf("%4s\t%3s\t%d\t%d\t%d\t%d\t%3.2f\t%2s\n",hakbun,name,kor,eng,math,tot,avg,grade);
		}
	}
}
