package NestedEx;

public class SungjukInnerEx02 {

	public static void main(String[] args) {
		SungjukInner sungjuk = new SungjukInner();
		sungjuk.addSungjuk();
		System.out.println();
		sungjuk.addSungjuk();
		System.out.println();
		sungjuk.addSungjuk();
		System.out.println();
		SungjukInner.Sungjuk obj = sungjuk.new Sungjuk();
		obj.input();
		obj.process();
		sungjuk.list.add(obj);
		System.out.println();
		printCart(sungjuk);
	
	}
	static void printCart(SungjukInner sungjuk) {
		int num = sungjuk.getSungjukNum();
		System.out.println("\t\t    *** ����ǥ ***");
		System.out.println("===========================================================");
		System.out.println("  �й�\t�̸�\t����\t����\t����\t����\t���\t���");
		System.out.println("===========================================================");
		
		for(int i=0;i<num;i++) {
			sungjuk.getSungjuk(i).output();
		}
		System.out.println("===========================================================");
		System.out.printf("\t�л���:%d   ��ü ���: %6.2f\n\n",
				num,sungjuk.getTotalAvg()/num);
		
	}
	
}
