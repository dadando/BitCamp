package NestedEx;

public class SungjukPyo {
	public static void main(String[] args) {
		Sungjuk2 sungjuk = new Sungjuk2();
		sungjuk.addList();
		System.out.println();
		sungjuk.addList();
		System.out.println();
		sungjuk.addList();
		System.out.println();
		printCart(sungjuk);
	}
	static void printCart(Sungjuk2 sungjuk) {
		int num = sungjuk.getListNum();
		System.out.println("\t\t    *** ����ǥ ***");
		System.out.println("===========================================================");
		System.out.println("  �й�\t�̸�\t����\t����\t����\t����\t���\t���");
		System.out.println("===========================================================");
		for(int cnt =0; cnt<num;cnt++) {
			Sungjuk2.Pyo obj = sungjuk.getList(cnt);
			obj.output();
		}
		System.out.println("===========================================================");
		System.out.printf("\t�л���:%d   ��ü ���: %6.2f\n\n",
				num,sungjuk.getTotalAvg()/num);
	
	}
}
