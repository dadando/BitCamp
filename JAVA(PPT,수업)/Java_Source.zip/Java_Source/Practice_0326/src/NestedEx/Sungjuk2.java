package NestedEx;

import java.util.ArrayList;
import java.util.Scanner;

public class Sungjuk2 {
	ArrayList<Pyo> list = new ArrayList<Pyo>();
	
	void addList() {
		Pyo obj = new Pyo();
		obj.input();
		for(Pyo hakbun:list) {
			if(hakbun.num.equals(obj.num)) {
				System.out.println("�й� �Է� ����(�ߺ�)!!");
				return;
			}
		}
		obj.process();
		list.add(obj);
		System.out.println("���� ���� �Է� ����!!");
	}
	
	int getListNum() {
		return list.size();
	}
	
	Pyo getList(int index) {
		return list.get(index);
	}
	
	void removeItem(Pyo obj) {
		list.remove(obj);
	}
	
	double getTotalAvg() {
		double totavg = 0.0;
		for(Pyo pyo:list) {
			totavg+=pyo.avg;
		}
		return totavg;
	}
	
	void changePyoNumber(int index) {
		Scanner scan = new Scanner(System.in);
		Pyo pyo = list.get(index);
		System.out.print("���� ����=> ");
		pyo.kor = scan.nextInt();
		System.out.print("���� ����=> ");
		pyo.eng = scan.nextInt();
		System.out.print("���� ����=> ");
		pyo.math = scan.nextInt();
		pyo.process();
	}
	
	class Pyo{
		String num, name;
		int kor, eng, math;
		int tot;
		double avg;
		String grade;
		
		public Pyo() {
			
		}
		
		void input() {
			Scanner scan = new Scanner(System.in);
			
			System.out.print("�й� �Է�=> ");
			num = scan.next();
			System.out.print("�̸� �Է�=> ");
			name = scan.next();
			System.out.print("���� ����=> ");
			kor = scan.nextInt();
			System.out.print("���� ����=> ");
			eng = scan.nextInt();
			System.out.print("���� ����=> ");
			math = scan.nextInt();
			System.out.println();
			
		}
		void process() {
			tot = kor+eng+math;
			avg = tot/3.;
			
			switch((int)avg/10) {
			case 10:
			case 9:
				grade = "��";
				break;
			case 8:
				grade = "��";
				break;
			case 7:
				grade = "��";
				break;
			case 6:
				grade = "��";
				break;
			default:
				grade = "��";
					
			}
		}
		void output() {
			System.out.printf("%4s\t%3s\t%d\t%d\t%d\t%d\t%3.2f\t%2s\n",num,name,kor,eng,math,tot,avg,grade);
		}
	}
}
