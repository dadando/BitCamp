package question_01;
import java.util.Scanner;

public class Sungjuk extends Person implements Personable {
	
	int kor,eng,math,tot;
	String hakbun,irum;
	double avg;
	String grade;
	
	Sungjuk() {
		
	}
	
	public boolean input() {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("�й� �Է�=> ");
		hakbun = scan.next();
		if(hakbun.equals("exit"))
			return true;
		System.out.print("�̸� �Է�=> ");
		irum = scan.next();
		System.out.print("���� ����=> ");
		kor = scan.nextInt();
		System.out.print("���� ����=> ");
		eng = scan.nextInt();
		System.out.print("���� ����=> ");
		math = scan.nextInt();
		System.out.println();
		return false;

	}
	
	void process() {
		tot = kor+eng+math;
		avg = tot/3.;
		
		switch((int)avg/10) {
		case 10:
		case 9:
			grade = "��";
			break;
		case 8:
			grade = "��";
			break;
		case 7:
			grade = "��";
			break;
		case 6:
			grade = "��";
			break;
		default:
			grade = "��";
		}
	}

	
	public void output() {
		System.out.printf("%4s\t%3s\t%d\t%d\t%d\t%d\t%3.2f\t%2s\n",hakbun,irum,kor,eng,math,tot,avg,grade);

	}

}
