package question_01;
import java.util.Scanner;

public class PersonInfo extends Person implements Personable {

	String phone;
	String addr;
	
	PersonInfo() {
			
	}
	public boolean input() {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("�й� �Է�=> ");
		hakbun = scan.next();
		if(hakbun.equals("exit"))
			return true;
		System.out.print("�̸� �Է�=> ");
		irum = scan.next();
		System.out.print("��ȭ��ȣ �Է�=> ");
		phone = scan.next();
		System.out.print("�ּ� �Է�=> ");
		addr = scan.next();
		System.out.println();
		return false;
	}

	
	public void output() {
		System.out.printf("%4s\t%3s\t%15s\t   %4s\n",hakbun,irum,phone,addr);

	}

}
