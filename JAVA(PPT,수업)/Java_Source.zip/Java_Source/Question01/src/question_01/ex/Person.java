package question_01.ex;

public class Person {
	String hakbun;
	String irum;
	
}

