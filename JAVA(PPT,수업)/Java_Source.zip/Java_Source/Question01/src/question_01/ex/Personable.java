package question_01.ex;

public interface Personable {
	
	abstract int input();
	abstract void output();
}
