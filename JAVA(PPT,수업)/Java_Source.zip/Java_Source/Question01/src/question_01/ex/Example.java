package question_01.ex;
public class Example {
	static int MAX = 100;
	public static void main(String[] args) {
		Sungjuk obj1[] = new Sungjuk[MAX];
		PersonInfo obj2[] = new PersonInfo[MAX];
		
		sungjukInput(obj1);
		personInput(obj2);
		printOutput(obj1,obj2);
		
	}
	
	static void sungjukInput(Sungjuk obj1[]) {
		
		System.out.println(" ### ���� �Է� ###");
		for(int i =0;i<MAX;i++) {
			obj1[i] = new Sungjuk();
			if(obj1[i].input()==1)
				break;
			obj1[i].process();
			Sungjuk.cnt++;
			
		}
	}
	static void personInput(PersonInfo obj2[]) {
		System.out.println("\n ### ���� ���� �Է� ###");
		for(int i=0;i<MAX;i++) {
			obj2[i] = new PersonInfo();
			if(obj2[i].input()==1)
				break;
			PersonInfo.cnt++;
		}
	}
	static void printOutput(Sungjuk obj1[],PersonInfo obj2[]) {
		System.out.println("\t\t    *** ����ǥ ***");
		System.out.println("===========================================================");
		System.out.println("  �й�\t�̸�\t����\t����\t����\t����\t���\t���");
		System.out.println("===========================================================");
		
		for(int i = 0;i<Sungjuk.cnt;i++) {
			obj1[i].output();
		}
		System.out.println("===========================================================");
		System.out.println();
		System.out.println("\t\t    *** ���� ���� ***");
		System.out.println("===================================================");
		System.out.println("  �й�\t�̸�\t   ��ȭ��ȣ\t     �ּ�");
		System.out.println("===================================================");
		
		for(int i = 0;i<PersonInfo.cnt;i++) {
			obj2[i].output();
		}
		System.out.println("===================================================");
	}
}
