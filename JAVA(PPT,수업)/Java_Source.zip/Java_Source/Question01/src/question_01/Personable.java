package question_01;

public interface Personable {
	
	abstract boolean input();
	abstract void output();
}
