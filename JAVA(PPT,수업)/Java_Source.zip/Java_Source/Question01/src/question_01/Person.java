package question_01;

import java.util.Calendar;

public class Person {
	public static void main(String args[]) {
		Calendar cal = Calendar.getInstance();
		System.out.println(cal.getTime());
	}
}

