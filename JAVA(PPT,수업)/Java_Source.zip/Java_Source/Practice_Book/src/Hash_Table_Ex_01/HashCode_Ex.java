package Hash_Table_Ex_01;

public class HashCode_Ex {

	public static void main(String[] args) {
		String str ="�Ӳ���";
		String str2="�Ӳ���";
		String str3="ȫ�浿";
		Integer num = 1;
		Integer num1 = 2;
		Character ch = 'a';
		Character ch1 = 'b';
		
		System.out.println(str.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str3.hashCode());
		System.out.println(num.hashCode());
		System.out.println(num1.hashCode());
		System.out.println(ch.hashCode());
		System.out.println(ch1.hashCode());
	}

}
