package Hash_Map_Ex_01;

public class TestParam {

	public static void main(String[] args) {
		printInt(3,4,5,6);
		printString("MBC","KBS","SBS");
		
	}
	static void printInt(int... arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
	static void printString(String... arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
}
