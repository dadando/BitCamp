package Hash_Map_Ex_01;

import java.util.*;

public class HashMapExample2 {

	public static void main(String[] args) {
		Map<Student,Integer> map = new HashMap<Student, Integer>();
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		String str = scan.next();
		map.put(new Student(1,"ȫ�浿"),95);
		map.put(new Student(2,"�Ӳ���"),100);
		
		if(map.containsKey(new Student(num,str))) {
			System.out.println("�����Ͱ� ����");
		}
		System.out.println("�� Entry ��: "+map.size());
		
	}

	

	

}
