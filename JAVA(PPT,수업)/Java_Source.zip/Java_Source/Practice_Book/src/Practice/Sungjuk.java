package Practice;

import java.util.Scanner;

public class Sungjuk {
	
	String hakbun;
	String irum;
	int kor,eng,math,tot;
	double avg;
	String grade;
	static int cnt=0;
	static double totavg = 0.0;
	
	void input() {
		Scanner scan = new Scanner(System.in);
		System.out.print("�й� �Է�=> ");
		hakbun = scan.next();
		System.out.print("�̸� �Է�=> ");
		irum = scan.next();
		System.out.print("���� �Է�=> ");
		kor = scan.nextInt();
		System.out.print("���� �Է�=> ");
		eng = scan.nextInt();
		System.out.print("���� �Է�=> ");
		math = scan.nextInt();
		System.out.println();
		
	}
	
	void process() {
		tot = kor+eng+math;
		avg = tot/3.;
		if(avg>=90) {
			grade = "��";
		}
		else if(avg>=80) {
			grade = "��";
		}
		else if(avg>=70) {
			grade = "��";
		}
		else if(avg>=60) {
			grade = "��";
		}
		else {
			grade = "��";
		}
		
	}
	
	void output() {
		System.out.printf("%4s   %4s     %3d     %3d     %3d     %3d   %3.2f      %s\n"
				,hakbun,irum,kor,eng,math,tot,avg,grade);
	}
	
}
