package Sungjuk_Graph;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class EventAction implements ActionListener {
	JTable table;
	JTextField text1,text2,text3,text4,text5;
	DrawingPanel drawingPanel;
	EventAction(){
		
	}
	EventAction(JTable table){
		this.table = table;
	}
	EventAction(JTable table,DrawingPanel drawingPanel){
		this.table = table;
		this.drawingPanel = drawingPanel;
	}
	EventAction(JTable table,JTextField text1,JTextField text2,JTextField text3,JTextField text4,JTextField text5){
		this(table);
		this.text1 = text1;
		this.text2 = text2;
		this.text3 = text3;
		this.text4 = text4;
		this.text5 = text5;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("�߰�")) {
			add();
		}else if(e.getActionCommand().equals("����")) {
			delete();
		}else if(e.getActionCommand().equals("����")) {
			revise();
		}else {
			graph();
		}
	}
	
	void add() {
		Sungjuk obj = new Sungjuk();
		int i,rowNum,flag =0;
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		obj.num=text1.getText();
		rowNum = model.getRowCount();
		for(i=0;i<rowNum;i++) {
			String hakbun = model.getValueAt(i, 0).toString().trim();
			if(hakbun.equals(obj.num)) {
				flag =1;
				break;
			}
		}
		if(flag==0) {
			obj.name = text2.getText().trim();
			obj.kor = Integer.parseInt(text3.getText().trim());
			obj.eng = Integer.parseInt(text4.getText().trim());
			obj.math = Integer.parseInt(text5.getText().trim());
			obj.process();
			
			Object arr[] = new Object[8];
			arr[0] = obj.num;
			arr[1] = obj.name;
			arr[2] = obj.kor;
			arr[3] = obj.eng;
			arr[4] = obj.math;
			arr[5] = obj.tot;
			arr[6] = obj.avg;
			arr[7] = obj.grade;
			
			model.addRow(arr);
			System.out.println("�л� ���� �Է� ����!!!");
		}
		else {
			System.out.println("�л� ���� �Է� ����(�ߺ�)!!!");
		}
		text1.setText("");
		text2.setText("");
		text3.setText("");
		text4.setText("");
		text5.setText("");
	}
	void delete() {
		int row = table.getSelectedRow();
		if(row==-1) {
			return;
		}
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		model.removeRow(row);
		System.out.println("�л� ���� ���� ����!!!");
	}
	void revise() {
		Sungjuk obj = new Sungjuk();
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		int rowNum = table.getRowCount();
		int i,flag=0;
		obj.num = text1.getText();
		
		for(i=0;i<rowNum;i++) {
			String hakbun = table.getValueAt(i, 0).toString();
			if(hakbun.equals(obj.num)) {
				obj.kor = Integer.parseInt(text3.getText().toString());
				obj.eng = Integer.parseInt(text4.getText().toString());
				obj.math = Integer.parseInt(text5.getText().toString());
				obj.process();
				model.setValueAt(obj.kor,i,2);
				model.setValueAt(obj.eng,i,3);
				model.setValueAt(obj.math,i,4);
				model.setValueAt(obj.tot,i,5);
				model.setValueAt(obj.avg,i,6);
				model.setValueAt(obj.grade,i,7);
				flag =1;
				break;
			}
		}
		if(flag==0) {
			System.out.println("���� ���� ���� ����!!");
		}else {
			System.out.println("���� ���� ���� ����!!");
		}
		text1.setText("");
        text2.setText("");
        text3.setText("");
        text4.setText("");
        text5.setText("");
	
	}
	void graph() {
		try {
			int row = table.getSelectedRow();
			if(row==-1) {
				return;
			}
			DefaultTableModel model = (DefaultTableModel)table.getModel();
			int korean = (int)model.getValueAt(row,2);
			int english = (int)model.getValueAt(row,3);
			int math = (int)model.getValueAt(row,4);
			double avg = (double)model.getValueAt(row,6);
			drawingPanel.setScores(korean,english,math,(int)avg);
			drawingPanel.repaint();
		}
		catch(NumberFormatException nfe) {
			JOptionPane.showMessageDialog(drawingPanel,"�߸��� ���� �����Դϴ�.",
					"���� �޽���",JOptionPane.ERROR_MESSAGE);
		}
	}

}
