package WrapperEx;

public class WrapperExample4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer obj = new Integer("10");
		int sum = obj+30;
		System.out.println(sum);
	}

}
