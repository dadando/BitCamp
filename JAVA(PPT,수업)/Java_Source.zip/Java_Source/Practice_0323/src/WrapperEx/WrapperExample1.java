package WrapperEx;

public class WrapperExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer obj1 = new Integer(12);
		Integer obj2 = new Integer(7);
		int sum = obj1.intValue()+obj2.intValue();
		System.out.println(sum);
	}

}
