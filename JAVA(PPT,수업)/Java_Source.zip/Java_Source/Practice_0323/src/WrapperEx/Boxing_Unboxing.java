package WrapperEx;

public class Boxing_Unboxing {

	public static void main(String[] args) {
		Integer num =12; //�ڵ� boxing
		Integer num1 = new Integer(123); //boxing
		int num3 = num.intValue();//unboxing
		System.out.println(num);
		System.out.println(num1); //�ڵ� unboxing
		System.out.println(num3);
	}

}
