package Practice;
import java.io.Serializable;
import java.util.Scanner;

public class ProductPyo implements Serializable{
	String code;
	String name;
	int su;
	int price;
	String grade;
	int amount;
	static int total_price;
	static int cnt = 0;
	
	
	ProductPyo(){
		
	}
	void input() {
		Scanner scan = new Scanner(System.in);
		System.out.print("��ǰ �ڵ� �Է�=> ");
		code = scan.next();
		System.out.print("��ǰ�� �Է�=> ");
		name = scan.next();
		System.out.print("���� �Է�=> ");
		su = scan.nextInt();
		System.out.print("�ܰ� �Է�=> ");
		price = scan.nextInt();
		
	}
	void process() {
		amount = su * price;
		
		switch(su/10) {
		case 10:
			grade = "���";
			break;
		case 9:
		case 8:
		case 7:
			grade = "����";
			break;
		case 6:
		case 5:
		case 4:
		case 3:
		case 2:
		case 1:
		case 0:
			grade = "�й�";
			break;
		default:
			grade = "���";
		}
	
	}
	void output() {
		System.out.printf("  %4s\t\t%4s\t %d\t%d\t%8d\t%2s\n",code,name,su,price,amount,grade);
	}
	static int print_total_price() {
		return total_price;
	}
}
