package Practice;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileDumpPractice3 {

	public static void main(String[] args) {
		FileReader in = null;
		FileWriter out = null;
		try {
			in = new FileReader("Sungjuk.java");
			out = new FileWriter("Sungjuk.java.bak3");
			while(true) {
				int num = in.read();
				if(num<0) {
					break;
				}
				out.write((char)num);
			}
		}
		catch(FileNotFoundException fnfe) {
			System.out.println("������ ã�� �� �����ϴ�.");
		}
		catch(IOException ioe) {
			System.out.println("������ ���� �� �����ϴ�.");
		}
		finally {
			try {
				in.close();
				out.close();
			}
			catch(Exception e) {
				
			}
		}

	}

}
