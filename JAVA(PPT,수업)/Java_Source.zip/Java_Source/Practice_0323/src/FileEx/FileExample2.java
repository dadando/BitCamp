package FileEx;

import java.io.*;

public class FileExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriter writer = null;
		try {
			File file = File.createTempFile("tmp", ".txt",new File("C:\\Temp"));
			writer = new FileWriter(file);
			writer.write('��');
			writer.write('��');
		}
		catch(IOException ioe) {
			System.out.println("�ӽ� ���Ͽ� �� �� �����ϴ�.");
		}
		finally {
			try {
				writer.close();
			}
			catch(Exception e) {
				
			}
		}
	}
}
