package FileEx;

import java.io.File;

public class FileEx01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("test.txt");
		try {
			file.createNewFile();
		}
		catch(Exception e) {
			
		}
	}

}
