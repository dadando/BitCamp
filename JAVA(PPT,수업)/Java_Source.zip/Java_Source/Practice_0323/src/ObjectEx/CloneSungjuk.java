package ObjectEx;

public class CloneSungjuk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sungjuk obj1 = new Sungjuk();
		obj1.input();
		obj1.process();
		Sungjuk obj2 = (Sungjuk)obj1.clone();
		if(obj1.equals(obj2)) {
			System.out.println("\n����\n");
			System.out.println(obj1.toString());
		}else {
			System.out.println("\n�ٸ���\n");
			System.out.println(obj2);
		}
		
	}

}
