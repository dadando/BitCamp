package ObjectEx;

public class ObjectSungjuk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sungjuk obj1 = new Sungjuk();
		Sungjuk obj2 = new Sungjuk();
		obj1.input();
		obj1.process();
		System.out.println();
		obj2.input();
		obj2.process();
		if(obj1.equals(obj2)) {
			System.out.println("\n����\n");
			System.out.println(obj1);
		}else {
			System.out.println("\n�ٸ���\n");
			System.out.println(obj2);
		}
	}

}
