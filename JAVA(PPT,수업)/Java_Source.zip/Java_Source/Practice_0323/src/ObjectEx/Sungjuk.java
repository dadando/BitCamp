package ObjectEx;
import java.io.Serializable;
import java.util.Scanner;

public class Sungjuk implements Serializable,Cloneable{
	String num, name;
	int kor, eng, math;
	int tot;
	double avg;
	String grade;
	
	static double totavg;
	static int cnt = 0;
	
	Sungjuk(){
		
	}
	
	void input() {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("�й� �Է�=> ");
		num = scan.next();
		System.out.print("�̸� �Է�=> ");
		name = scan.next();
		System.out.print("���� ����=> ");
		kor = scan.nextInt();
		System.out.print("���� ����=> ");
		eng = scan.nextInt();
		System.out.print("���� ����=> ");
		math = scan.nextInt();
		System.out.println();
		
	}
	void process() {
		tot = kor+eng+math;
		avg = tot/3.;
		
		switch((int)avg/10) {
		case 10:
		case 9:
			grade = "��";
			break;
		case 8:
			grade = "��";
			break;
		case 7:
			grade = "��";
			break;
		case 6:
			grade = "��";
			break;
		default:
			grade = "��";
				
		}
	}
	void output() {
		System.out.printf("%4s\t%3s\t%d\t%d\t%d\t%d\t%3.2f\t%2s\n",num,name,kor,eng,math,tot,avg,grade);
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Sungjuk))  //ĳ��Ʈ�� �����ϸ� true �Ұ����ϸ� false
			return false;
		Sungjuk pyo = (Sungjuk)obj;
		if( (num.equals(pyo.num))&&(name.equals(pyo.name))&&(kor==pyo.kor)
				&&(eng==pyo.eng)&&(math==pyo.math))
			return true;
		else
			return false;
		
	}
	public String toString() {
		String str = "�й�: "+num +"\n�̸�: "+name+"\n����: "+kor
				+"\n����: "+eng+"\n����: "+math+"\n����: "+tot+"\n���: "+grade+"\n";
		return str;
	}
	public Object clone() {
		try {
			return super.clone();
		}
		catch(CloneNotSupportedException e) {
			return null;
		}
	}
}
