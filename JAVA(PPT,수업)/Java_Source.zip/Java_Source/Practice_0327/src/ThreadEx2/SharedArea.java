package ThreadEx2;

class SharedArea {
	double result;
	boolean isReady;
}
