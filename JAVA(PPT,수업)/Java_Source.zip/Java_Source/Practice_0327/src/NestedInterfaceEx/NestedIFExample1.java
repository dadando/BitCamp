package NestedInterfaceEx;

//import NestedInterfaceEx.MP3PlayerFactory.MP3Player;

public class NestedIFExample1 {

	public static void main(String[] args) {
		MP3PlayerFactory factory = new MP3PlayerFactory();
		PlayerFactory.Player player = factory.createPlayer();
		//MP3PlayerFactory.MP3Player player = (MP3Player)factory.createPlayer();
		player.play("�Ƹ���");
		player.stop();
	}

}
