package StateEx;

class SharedArea {
	double result;
	boolean isReady;
}
