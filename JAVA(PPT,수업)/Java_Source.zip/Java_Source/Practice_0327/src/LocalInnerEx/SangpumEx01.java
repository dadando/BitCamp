package LocalInnerEx;

public class SangpumEx01 {

	public static void main(String[] args) {
		Sangpum obj = new Sangpum() {
			void output() {
				System.out.println("\t\t*** ��ǰ ���� ***");
				System.out.println("============================================");
				System.out.println("   ��ǰ�ڵ�  ��ǰ��\t����\t�ܰ�\t�ݾ�\t��");
				System.out.println("============================================");
				System.out.printf("%6s %6s %4d  %7d %8d   %2s\n",
						code, irum, su, dan, price, grade);
				System.out.println("============================================");
				
			}
		};
		obj.input();
		obj.process();
		obj.output();

	}

}
