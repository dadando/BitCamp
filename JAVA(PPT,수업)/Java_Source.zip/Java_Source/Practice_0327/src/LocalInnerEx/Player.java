package LocalInnerEx;

public interface Player {
	abstract public void play(String source);
	abstract public void stop();
}
