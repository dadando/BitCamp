package LocalInnerEx;

abstract class MessageSender {
	abstract void send(String message);
}
