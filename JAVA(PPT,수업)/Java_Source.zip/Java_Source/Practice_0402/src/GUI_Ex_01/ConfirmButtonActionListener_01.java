package GUI_Ex_01;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class ConfirmButtonActionListener_01 implements ActionListener {
	JTextField text;
	JLabel label;
	ConfirmButtonActionListener_01(JTextField text,JLabel label){
		this.text = text;
		this.label = label;
	}
	
	public void actionPerformed(ActionEvent e) {
		String str = text.getText();
		label.setText(str);
	}

}
