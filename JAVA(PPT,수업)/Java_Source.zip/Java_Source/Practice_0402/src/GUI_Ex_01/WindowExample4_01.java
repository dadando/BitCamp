package GUI_Ex_01;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowExample4_01 {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Fruit Program");
		frame.setLocation(400,400);
		Container contentpane = frame.getContentPane();
		FlowLayout layout = new FlowLayout();
		contentpane.setLayout(layout);
		contentpane.add(new JButton("���"));
		contentpane.add(new JButton("����"));
		contentpane.add(new JButton("������"));
		contentpane.add(new JButton("���ξ���"));
		contentpane.add(new JButton("��"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);

	}

}
