package GUI_Ex_01;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

public class WindowExample2_01 {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Hello Program");
		frame.setPreferredSize(new Dimension(300,80));
		frame.setLocation(500, 500);
		Container contentpane = frame.getContentPane();
		JTextField text = new JTextField();
		JButton button = new JButton("Ȯ��");
		JLabel label = new JLabel();
		contentpane.add(text,BorderLayout.CENTER);
		contentpane.add(button,BorderLayout.EAST);
		contentpane.add(label,BorderLayout.SOUTH);
		ActionListener obj = new ConfirmButtonActionListener_01(text,label);
		button.addActionListener(obj);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);

	}

}
