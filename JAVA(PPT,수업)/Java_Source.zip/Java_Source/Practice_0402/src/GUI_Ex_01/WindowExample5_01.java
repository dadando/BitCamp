package GUI_Ex_01;

import java.awt.Container;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowExample5_01 {
	
	public static void main(String args[]) {
		JFrame frame = new JFrame("Cafe Program");
		frame.setLocation(800,500);
		Container contentpane = frame.getContentPane();
		BoxLayout layout = new BoxLayout(contentpane,BoxLayout.X_AXIS);
		contentpane.setLayout(layout);
		contentpane.add(new JButton("�Ƹ޸�ī��"));
		contentpane.add(new JButton("ī���"));
		contentpane.add(new JButton("ī���ī"));
		contentpane.add(new JButton("����������"));
		contentpane.add(new JButton("��������"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}
