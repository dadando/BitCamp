package Inner_Ex;

import java.util.ArrayList;
import java.util.Scanner;

public class MemberInner {
	ArrayList<Member> list = new ArrayList<Member>();
	
	MemberInner(){
	}
	
	void addMember() {
		Member obj = new Member();
		obj.inputData();
		if(checkMember(obj)) {
			System.out.println("�̸� �Է� ����(�ߺ�)!!");
			return;
		}
		list.add(obj);
	}
	void removeMember(Member obj) {
		list.remove(obj);
	}
	int getMemberNum() {
		return list.size();
	}
	boolean checkMember(Member obj) {
		for(Member dat:list) {
			if(dat.irum.equals(obj.irum)) {
				return true;
			}
		}
		return false;
	}
	ArrayList<Member> getList(){
		return list;
	}
	Member getMember(int index) {
		return list.get(index);
	}
	void changeMember(int index) {
		Scanner scan = new Scanner(System.in);
		Member member = getMember(index);
		System.out.print("���� �Է�=> ");
		member.gender = scan.next();
		System.out.print("�̸��� �Է�=> ");
		member.email = scan.next();
		System.out.print("���̵� �Է�=> ");
		member.id = scan.next();
		System.out.print("�н����� �Է�=> ");
		member.passwd = scan.next();
	}
	
	class Member{
		String irum,gender,email,id,passwd;
		
		Member(){
		}
		
		public void inputData() {
			Scanner scan = new Scanner(System.in);
			System.out.print("�̸� �Է�=> ");
			irum = scan.next();
			System.out.print("���� �Է�=> ");
			gender = scan.next();
			System.out.print("�̸��� �Է�=> ");
			email = scan.next();
			System.out.print("���̵� �Է�=> ");
			id = scan.next();
			System.out.print("�н����� �Է�=> ");
			passwd = scan.next();
		}
		
		public void outputData() {
			
			System.out.printf("%3s  %6s %10s%10s %10s\n",irum,gender,email,id,passwd);
		}
		
	}
}
