package GUI_Ex_02;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class WindowExample_02_01 {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Program");
		frame.setLocation(400,400);
		frame.setPreferredSize(new Dimension(200,80));
		Container contentpane = frame.getContentPane();
		JTextField text = new JTextField();
		JLabel label = new JLabel("�Է�: ");
		JButton button = new JButton("Ȯ��");
		contentpane.add(button,BorderLayout.EAST);
		contentpane.add(text,BorderLayout.CENTER);
		contentpane.add(label,BorderLayout.SOUTH);
		ActionListener action = new ConfirmButtonActionListener_03(text,label);
		button.addActionListener(action);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		

	}

}
