package GUI_Ex_02;

import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowExample3_02 {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Zoo Program");
		frame.setLocation(400,400);
		Container contentpane = frame.getContentPane();
		GridLayout layout = new GridLayout(3,2);
		frame.setLayout(layout);
		contentpane.add(new JButton("ȣ����"));
		contentpane.add(new JButton("����"));
		contentpane.add(new JButton("�⸰"));
		contentpane.add(new JButton("ġŸ"));
		contentpane.add(new JButton("������"));
		contentpane.add(new JButton("�ڳ���"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);

	}

}
