package GUI_Ex_02;

import java.awt.Container;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowExample5_02 {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Cafe Program");
		frame.setLocation(400,400);
		Container contentpane = frame.getContentPane();
		BoxLayout layout = new BoxLayout(contentpane,BoxLayout.X_AXIS);
		frame.setLayout(layout);
		contentpane.add(new JButton("�Ƹ޸�ī��"));
		contentpane.add(new JButton("īǪġ��"));
		contentpane.add(new JButton("ī���"));
		contentpane.add(new JButton("����������"));
		contentpane.add(new JButton("ī���ī"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}
