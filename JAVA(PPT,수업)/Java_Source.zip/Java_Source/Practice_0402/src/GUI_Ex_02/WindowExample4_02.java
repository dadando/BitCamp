package GUI_Ex_02;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowExample4_02 {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Fruit Program");
		frame.setLocation(400,400);
		Container contentpane = frame.getContentPane();
		FlowLayout layout = new FlowLayout();
		frame.setLayout(layout);
		contentpane.add(new JButton("Apple"));
		contentpane.add(new JButton("Banana"));
		contentpane.add(new JButton("Pear"));
		contentpane.add(new JButton("Pineapple"));
		contentpane.add(new JButton("Cherry"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		
		

	}

}
