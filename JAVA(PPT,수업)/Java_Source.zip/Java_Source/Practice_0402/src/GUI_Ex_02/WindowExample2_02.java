package GUI_Ex_02;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class WindowExample2_02 {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Hello Program");
		frame.setLocation(400,400);
		frame.setPreferredSize(new Dimension(200,80));
		Container contentpane = frame.getContentPane();
		JTextField text = new JTextField();
		JButton button = new JButton("Ȯ��");
		JLabel label = new JLabel("Hello");
		contentpane.add(text,BorderLayout.CENTER);
		contentpane.add(button,BorderLayout.EAST);
		contentpane.add(label,BorderLayout.SOUTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);

	}

}
