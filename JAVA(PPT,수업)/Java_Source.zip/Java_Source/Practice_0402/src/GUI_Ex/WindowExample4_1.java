package GUI_Ex;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowExample4_1 {

	public static void main(String[] args) {
		// TODO BorderLayout���
		JFrame frame = new JFrame("Zoo Program");
		frame.setLocation(500,400);
		frame.setPreferredSize(new Dimension(360,300));
		Container contentpane = frame.getContentPane();
		JButton text1 = new JButton("��踻");
		text1.setPreferredSize(new Dimension(200,50));
		JButton text2 = new JButton("����");
		text2.setPreferredSize(new Dimension(80,200));
		JButton text3 = new JButton("�ڳ���");
		text3.setPreferredSize(new Dimension(80,200));
		JButton text4 = new JButton("�ڻԼ�");
		JButton text5 = new JButton("���");
		text5.setPreferredSize(new Dimension(200,50));
		contentpane.add(text1, BorderLayout.NORTH);
		contentpane.add(text2, BorderLayout.EAST);
		contentpane.add(text3, BorderLayout.WEST);
		contentpane.add(text4, BorderLayout.CENTER);
		contentpane.add(text5, BorderLayout.SOUTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}
