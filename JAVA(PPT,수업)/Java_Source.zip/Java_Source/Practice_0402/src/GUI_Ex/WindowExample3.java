package GUI_Ex;

import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowExample3 {

	public static void main(String[] args) {
		// TODO grid layout ���
		JFrame frame = new JFrame("Zoo Program");
		frame.setLocation(500,400);
		Container contentpane = frame.getContentPane();
		GridLayout layout = new GridLayout(3,2);
		contentpane.setLayout(layout);
		contentpane.add(new JButton("��踻"));
		contentpane.add(new JButton("����"));
		contentpane.add(new JButton("�ڳ���"));
		contentpane.add(new JButton("�ڻԼ�"));
		contentpane.add(new JButton("���"));
		contentpane.add(new JButton("���ֳ̾�"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}
