package GUI_Ex;

import java.awt.Container;
import javax.swing.BoxLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class WindowExample5 {

	public static void main(String[] args) {
		// TODO box layout ���
		JFrame frame = new JFrame("Cafe Program");
		frame.setLocation(500,400);
		Container contentpane = frame.getContentPane();
		BoxLayout layout = new BoxLayout(contentpane,BoxLayout.X_AXIS);
		contentpane.setLayout(layout);
		contentpane.add(new JButton("�ڹ�"));
		contentpane.add(new JButton("����������"));
		contentpane.add(new JButton("īǪġ��"));
		contentpane.add(new JButton("���縶��ƾ"));
		contentpane.add(new JButton("�ݷ����"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}
