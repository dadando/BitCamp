package SocketEx;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class ClientExample1 {

	public static void main(String[] args) {
		Socket socket = null;
		try {
			//loopback address "127.0.0.1" �׽�Ʈ�� IP�ּ�
			socket = new Socket("127.0.0.1",9000);
			InputStream in = socket.getInputStream();
			OutputStream out = socket.getOutputStream();
			String str = "Hello, Server";
			out.write(str.getBytes());
			byte arr[] = new byte[100];
			in.read(arr);
			System.out.println(new String(arr));
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				socket.close();
			}
			catch(Exception e){
				
			}
		}

	}

}
// cmd â���� cd�� �̿��Ͽ� ��� ����
// ������ �׻� bin �������� ����
// C:\Project156\Java_Source\Practice_0407\bin>java SocketEx/ServerExample1