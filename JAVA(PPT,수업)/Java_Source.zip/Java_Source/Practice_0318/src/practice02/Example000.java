package practice02;

public class Example000 {
	final static int MAX =100;
	public static void main(String[] args) {
		Sungjuk obj1[] = new Sungjuk[MAX];
		PersonInfo obj2[] = new PersonInfo[MAX];
		
		int cnt1 = sungjukInput(obj1);
		int cnt2 = personInput(obj2);
		
		System.out.println("\t\t    *** ����ǥ ***");
		System.out.println("===========================================================");
		System.out.println("  �й�\t�̸�\t����\t����\t����\t����\t���\t���");
		System.out.println("===========================================================");
		printOut(obj1,cnt1);
		System.out.println("===========================================================");
		System.out.println();
		System.out.println("\t\t    *** ���� ���� ***");
		System.out.println("===================================================");
		System.out.println("  �й�\t�̸�\t   ��ȭ��ȣ\t     �ּ�");
		System.out.println("===================================================");
		printOut(obj2,cnt2);
		System.out.println("===================================================");
	}
	static int sungjukInput(Sungjuk obj1[]) {
		int cnt1 = 0;
		
		System.out.println("### �������� �Է� ###");
		for(int i=0;i<MAX;i++) {
			obj1[i] = new Sungjuk();
			if(obj1[i].input())
				break;
			obj1[i].process();
			cnt1++;
		}
		
		return cnt1;
	}
	static int personInput(PersonInfo obj2[]) {
		int cnt2 = 0;
		System.out.println("\n### �������� �Է� ###");
		for(int i=0;i<MAX;i++) {
			obj2[i] = new PersonInfo();
			
			if(obj2[i].input())
				break;
			cnt2++;
		}
		
		return cnt2;
	}
	static void printOut(Personable obj[],int cnt) {
		for(int i=0;i<cnt;i++) {
			obj[i].output();
		}
	}
}
