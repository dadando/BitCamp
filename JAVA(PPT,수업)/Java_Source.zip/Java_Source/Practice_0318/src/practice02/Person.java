package practice02;

public class Person {
	String hakbun;
	String name;
	Person(){
		
	}
}
