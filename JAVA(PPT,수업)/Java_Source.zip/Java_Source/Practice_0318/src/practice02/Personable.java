package practice02;

public interface Personable {
	public abstract boolean input();
	public abstract void output();
}
