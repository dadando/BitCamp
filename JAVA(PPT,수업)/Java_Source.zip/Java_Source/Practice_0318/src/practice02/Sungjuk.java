package practice02;

import java.util.Scanner;

public class Sungjuk extends Person implements Personable {

	int kor,eng,math,tot;
	double avg;
	String grade;
	Sungjuk(){
		//super();
	}
	public boolean input() {
		Scanner scan = new Scanner(System.in);
		System.out.print("�й��Է�=> ");
		hakbun = scan.next();
		if(hakbun.toLowerCase().equals("exit"))
			return true;
		System.out.print("�̸��Է�=> ");
		name = scan.next();
		System.out.print("�����Է�=> ");
		kor = scan.nextInt();
		System.out.print("�����Է�=> ");
		eng = scan.nextInt();
		System.out.print("�����Է�=> ");
		math = scan.nextInt();
		System.out.println();
		return false;
	}
	void process() {
		tot = kor+eng+math;
		avg = tot/3.;
		switch((int)avg/10) {
		case 10:
		case 9:
			grade = "��";
			break;
		case 8:
			grade = "��";
			break;
		case 7:
			grade = "��";
			break;
		case 6:
			grade = "��";
			break;
		default:
			grade = "��";
		}
		
	}

	
	public void output() {
		System.out.printf("%4s\t%3s\t%d\t%d\t%d\t%d\t%6.2f\t%s\n",hakbun,name,kor,eng,math,tot,avg,grade);

	}

}
