package sungjukEx;

public class TestEx03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sungjuk02 arr[] = new Sungjuk02[2];
		inputData(arr);
		System.out.println();
		printData(arr);

	}
	static void inputData(Sungjuk02 arr2[]) {
		for(int i = 0; i<arr2.length; i++) {
			arr2[i] = new Sungjuk02();
			arr2[i].input();
			arr2[i].process();
		}
	}
	static void printData(Sungjuk02 arr2[]) {
		for(int i=0;i<arr2.length;i++)
			arr2[i].output();
	}
}
