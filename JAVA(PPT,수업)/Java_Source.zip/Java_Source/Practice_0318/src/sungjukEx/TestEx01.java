package sungjukEx;

public class TestEx01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = {10, 20, 30};
		printData(arr);
	}
	
	static void printData(int arr2[]) {
		for(int i=0;i<arr2.length;i++)
			System.out.println(arr2[i]);
	}

}
