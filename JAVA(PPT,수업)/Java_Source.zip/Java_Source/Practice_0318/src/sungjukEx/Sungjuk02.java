package sungjukEx;
import java.util.Scanner;

public class Sungjuk02 {
	String num;
	String name;
	int kor;
	int eng;
	int math;
	int tot;
	double avg;
	String grade;
	
	static int cnt = 0;
	static double tot_avg = 0.0;
	
	Sungjuk02(){
		
	}
	Sungjuk02(String num){
		this.num=num;
	}
	
	
	void input() {
		Scanner scan = new Scanner(System.in);
		
		System.out.print(" �й� �Է�=> ");
		num = scan.next();
		System.out.print(" �̸� �Է�=> ");
		name = scan.next();
		System.out.print(" ���� ����=> ");
		kor = scan.nextInt();
		System.out.print(" ���� ����=> ");
		eng = scan.nextInt(); // ����
		System.out.print(" ���� ����=> ");
		math = scan.nextInt(); // ����
		
		
	}
	
	double process() {
		
		tot = kor + eng + math;
		avg = tot/3.;
		grade = null;
		tot_avg+=avg;
		
		switch((int)(avg/10)) {
		case 10:
		case 9:
				
			grade = "��";
			break;
		case 8:
			grade = "��";
			break;
						
		case 7:
			grade = "��";
			break;
		case 6:
			grade = "��";
			break;
		case 5:
		case 4:
		case 3:
		case 2:
		case 1:
		case 0:
			grade = "��";
			break;
		}
		return avg;
	}
	
	void output() {
		System.out.printf("%4s\t%3s\t%3d\t%3d\t%3d\t%3d\t%6.2f\t%2s\n"
					,num,name,kor,eng,math,tot,avg,grade);
	}
	static double getTotal_avg() {
		return tot_avg / cnt;
		
	}
	
}