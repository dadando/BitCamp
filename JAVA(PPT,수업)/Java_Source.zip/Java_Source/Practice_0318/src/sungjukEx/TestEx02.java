package sungjukEx;

public class TestEx02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String arr[] = {"MBC","KBS","SBS"};
		printData(arr);
	}
	static void printData(String arr2[]) {
		for(int i = 0; i<arr2.length; i++)
			System.out.println(arr2[i]);
	}

}
