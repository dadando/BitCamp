package practice;

public class Clothing {
	String code,name,material;
	Season season;
	Clothing(String code,String name,String material,Season season){
		this.code = code;
		this.name = name;
		this.material = material;
		this.season = season;
	}
}
