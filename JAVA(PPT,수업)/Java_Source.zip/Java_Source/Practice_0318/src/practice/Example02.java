package practice;

public class Example02 {

	public static void main(String[] args) {
		Clothing cloth = new Clothing("111-1111","�е�","�����ٿ�",Season.WINTER);
		System.out.println("code = "+cloth.code);
		System.out.println("name = "+cloth.name);
		System.out.println("material = "+cloth.material);
		System.out.println("season = "+cloth.season);

	}

}
