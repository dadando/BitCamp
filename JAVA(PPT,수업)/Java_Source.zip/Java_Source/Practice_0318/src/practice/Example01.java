package practice;

public class Example01 {

	public static void main(String[] args) {
		
		printOf(Day.SUNDAY);
		printOf(Day.SATURDAY);
		printOf(Day.FRIDAY);
		printOf(Day.MONDAY);
	}
	static void printOf(Day day) {
		System.out.println(day.days());
	}

}
