package interfaceEx02;

public class SeparateVolume implements Lendable01 {
	String requestNo,bookTitle,writer,borrower,checkOutdate;
	byte state;
	
	SeparateVolume(String requestNo,String bookTitle,String writer){
		this.requestNo = requestNo;
		this.bookTitle = bookTitle;
		this.writer = writer;
	}
	public void checkout(String borrower, String date) {
		if(state !=STATE_BORROWED) {
			return;
		}
		this.borrower = borrower;
		this.checkOutdate = date;
		this.state = STATE_BORROWED;
		System.out.println("*"+bookTitle+" ��(��) ����Ǿ����ϴ�.");
		System.out.println("������: "+borrower);
		System.out.println("������: "+date);
	}

	public void checkin() {
		if(state != STATE_NORMAL) {
			return;
		}
		this.borrower = null;
		this.checkOutdate = null;
		this.state = STATE_NORMAL;
		System.out.println("*"+bookTitle+" ��(��) �ݳ��Ǿ����ϴ�.");
	}

}
