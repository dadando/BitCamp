package interfaceEx02;

interface Lendable01 {
	final static byte STATE_BORROWED = 1;
	final static byte STATE_NORMAL = 0;
	abstract void checkout(String borrower,String date);
	abstract void checkin();
}
