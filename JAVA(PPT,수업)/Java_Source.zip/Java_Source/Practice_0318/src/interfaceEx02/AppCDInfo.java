package interfaceEx02;

public class AppCDInfo extends CDInfo implements Lendable01 {

	String borrower;
	String checkOutdate;
	byte state;
	AppCDInfo(String registerNo, String title) {
		super(registerNo, title);
		
	}

	
	public void checkout(String borrower, String date) {
		if(state != STATE_NORMAL) {
			return;
		}
		this.borrower = borrower;
		this.checkOutdate = date;
		this.state = STATE_BORROWED;
		System.out.println("*"+title+"CD�� ����Ǿ����ϴ�.");
		System.out.println("������: "+borrower);
		System.out.println("������: "+date);

	}

	
	public void checkin() {
		this.borrower = null;
		this.checkOutdate = null;
		this.state = STATE_NORMAL;
		System.out.println("*"+title+"CD�� �ݳ��Ǿ����ϴ�.");

	}

}
