package interfaceEx02;

public class Interface_Practice {

	public static void main(String[] args) {
		SeparateVolume obj = new SeparateVolume("aaa-000","�G�G�G","����");
		AppCDInfo obj2 = new AppCDInfo("bbb-111","CDCDII");

	}

}
