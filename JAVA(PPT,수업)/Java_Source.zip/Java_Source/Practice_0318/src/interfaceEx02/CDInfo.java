package interfaceEx02;

public class CDInfo {
	String registerNo;
	String title;
	CDInfo(String registerNo,String title){
		this.registerNo = registerNo;
		this.title = title;
	}
}
