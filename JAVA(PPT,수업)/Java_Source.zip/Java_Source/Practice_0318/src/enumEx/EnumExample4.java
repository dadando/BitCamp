package enumEx;

public class EnumExample4 {

	public static void main(String[] args) {
		
		printOf(Day.MONDAY);
		printOf(Day.SUNDAY);
		

	}
	static void printOf(Day day) {
		System.out.println(day.value());
	}

}
