package inheritanceEx02;

public class RefTypeExample {

	public static void main(String[] args) {
		Account obj = new CheckingAccount("111-22-33333333","ȫ�浿",100000,"1111-1111");
		if(obj instanceof CheckingAccount)
			pay((CheckingAccount)obj);
		else
			System.out.println("ĳ��Ʈ�� �� ���� Ÿ���Դϴ�.");
		
	}
	static void pay(CheckingAccount obj) {
		try {
			int amount = obj.pay("1111-1111",47000);
			System.out.println("�����: "+amount);
			System.out.println("ī���ȣ: "+obj.cardNo);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
