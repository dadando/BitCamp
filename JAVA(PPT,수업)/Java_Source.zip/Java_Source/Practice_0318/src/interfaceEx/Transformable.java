package interfaceEx;

public interface Transformable extends Movable{
	void resize(int width, int height);

}
