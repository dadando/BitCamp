package interfaceEx;

public class SeparateVolume implements Lendable{
	String requestNo;
	String bookTitle;
	String writer;
	String borrower;
	String checkOutdate;
	byte state;
	SeparateVolume(String requestNo, String bookTitle, String writer){
		this.requestNo = requestNo;
		this.bookTitle = bookTitle;
		this.writer = writer;
	}
	public void checkOut(String borrower, String date) {
		if(state !=STATE_NORMAL)
			return;
		this.borrower = borrower;
		this.checkOutdate = date;
		this.state = STATE_BORROWED;
		System.out.println("*"+bookTitle+"��(��) ����Ǿ����ϴ�.");
		System.out.println("������: "+borrower);
		System.out.println("������: "+checkOutdate+"\n");
	}
	public void checkIn() {
		this.borrower = null;
		this.checkOutdate = null;
		this.state = STATE_NORMAL;
		System.out.println("*"+bookTitle+"��(��) �ݳ��Ǿ����ϴ�.\n");
	}

}
