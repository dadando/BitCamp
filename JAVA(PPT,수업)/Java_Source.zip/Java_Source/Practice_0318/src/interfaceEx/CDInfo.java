package interfaceEx;

public class CDInfo {
	String registerNo;
	String title;
	CDInfo(String registerNo,String title){
		this.registerNo = registerNo;
		this.title = title;
		
	}
}
