package inheritanceEx;

public class CheckingAccount extends Account  { 
    String cardNo;      
    
    CheckingAccount(String accountNO,String ownerName,
    		int balance,String cardNO){
    	
    	super(accountNO,ownerName,balance);
    	this.cardNo = cardNO;
    	
    }
    
    int pay(String cardNo, int amount) throws Exception {   
        if (!cardNo.equals(this.cardNo) || (balance < amount)) 
            throw new Exception("������ �Ұ����մϴ�."); 
        return withdraw(amount); 
    } 
} 