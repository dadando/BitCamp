/*�Ϲ� ���ν����� �̿�
create or replace procedure call_search(
    vhakbun in out varchar2,
    vname out varchar2,
    vaddr out varchar2,
    vphone out varchar2)
is
begin
    select hakbun,name,addr,phone
    into vhakbun,vname,vaddr,vphone
    from member
    where hakbun = vhakbun;
end;
/
*/


package CollableStatement_Ex;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;

import oracle.jdbc.OracleTypes;

public class SearchExam_CALL {

	public static void main(String[] args) {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
		Connection con = null;
		CallableStatement cstmt = null;
		
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			Class.forName(driver);
			con = DriverManager.getConnection(url,"scott","123456");
			System.out.print("��ȸ�� �й� �Է�=> ");
			String hakbun = br.readLine().toUpperCase();
			
			cstmt = con.prepareCall("{call call_search(?,?,?,?)}");
			cstmt.setString(1, hakbun);
			cstmt.registerOutParameter(1, OracleTypes.VARCHAR);
			cstmt.registerOutParameter(2, OracleTypes.VARCHAR);
			cstmt.registerOutParameter(3, OracleTypes.VARCHAR);
			cstmt.registerOutParameter(4, OracleTypes.VARCHAR);
			
			cstmt.executeQuery();
			
			System.out.println();
			System.out.println("hakbun\tname\taddr\tphone");
			System.out.println("------------------------------------------");
			System.out.print(cstmt.getString(1) +"\t");
			System.out.print(cstmt.getString(2) +"\t");
			System.out.print(cstmt.getString(3) +"\t");
			System.out.print(cstmt.getString(4) +"\n");
		}
		catch(Exception e) {
			System.out.println("���� �߻�!! "+e.getMessage());
		}
		finally {
			try {
				if(con!=null) con.close();
				if(cstmt!=null) cstmt.close();
				//if(rs!=null) rs.close();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
