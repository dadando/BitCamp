/*
 * create or replace procedure call_insert(
    hakbun member.hakbun%type,
    name member.name%type,
    addr member.addr%type,
    phone member.phone%type)
is
begin
    insert into member values(hakbun,name,addr,phone);
end;
/
*/

package CollableStatement_Ex;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;

public class InsertExam_CALL {

	public static void main(String[] args) {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
		Connection con = null;
		CallableStatement cstmt = null;
		String hakbun,name,addr,phone;
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Member ���̺��� �� �߰��ϱ�...");
			System.out.print("�й� �Է�: ");
			hakbun = br.readLine();
			System.out.print("�̸� �Է�: ");
			name = br.readLine();
			System.out.print("�ּ� �Է�: ");
			addr = br.readLine();
			System.out.print("��ȭ��ȣ �Է�: ");
			phone = br.readLine();
			
			Class.forName(driver);
			con = DriverManager.getConnection(url,"scott","123456");
			
			cstmt=con.prepareCall("{call call_insert(?,?,?,?)}");
			cstmt.setString(1,hakbun);
			cstmt.setString(2,name);
			cstmt.setString(3,addr);
			cstmt.setString(4,phone);
			cstmt.executeUpdate();
			//int res = cstmt.executeUpdate();
			//System.out.println(res);
			System.out.println("������ ���̽� ���� ����!");
		}
		catch(Exception e) {
			System.out.println("���� �߻�! : "+e.getMessage());
		}
		finally {
			try {
				if(con!=null) con.close();
			}
			catch(Exception ignored) {
			}
			try {
				if(cstmt!=null) cstmt.close();
			}
			catch(Exception ignored){
			}
		}
	}
}
