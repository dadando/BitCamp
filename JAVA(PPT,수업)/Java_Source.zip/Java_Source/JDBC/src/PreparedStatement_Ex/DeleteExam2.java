package PreparedStatement_Ex;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DeleteExam2 {

	public static void main(String[] args) {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
		Connection con = null;
		PreparedStatement pstmt = null;
		
		String sql = "delete from member where hakbun=?";
		
		try {
			BufferedReader in= new BufferedReader(
					new InputStreamReader(System.in));
			Class.forName(driver);
			con = DriverManager.getConnection(url,"scott","123456");
			System.out.println("Member���̺� �� �����ϱ�...");
			System.out.print("������ �й� �Է� : ");
			String del_hakbun = in.readLine();
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, del_hakbun);
			pstmt.executeUpdate();
			System.out.println(sql);
			System.out.println("������ ���� �Ϸ�!");
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				if(con!=null) con.close();
				if(pstmt!=null) pstmt.close();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
