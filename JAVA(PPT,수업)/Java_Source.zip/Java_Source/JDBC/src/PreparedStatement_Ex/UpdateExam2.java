package PreparedStatement_Ex;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UpdateExam2 {

	public static void main(String[] args) {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
		Connection con = null;
		PreparedStatement pstmt = null;
		
		String sql = "update member set addr=?,phone=? where hakbun=?";
		try {
			BufferedReader in= new BufferedReader(
					new InputStreamReader(System.in));
			Class.forName(driver);
			con = DriverManager.getConnection(url,"scott","123456");
			System.out.println("Member���̺� �� �����ϱ�...");
			System.out.print("������ �й� �Է� : ");
			String new_hakbun = in.readLine();
			System.out.print("�� �ּ� �Է� : ");
			String new_addr = in.readLine();
			System.out.print("�� ��ȭ��ȣ �Է� : ");
			String new_phone = in.readLine();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, new_addr);
			pstmt.setString(2, new_phone);
			pstmt.setString(3, new_hakbun);
			
			pstmt.executeUpdate();
			System.out.println(sql);
			System.out.println("������ ���̽� ���� ����!!");
		}
		catch(Exception e) {
			System.out.println("���� �߻�! : "+e.getMessage());
		}
		finally {
			try {
				if(con!=null) con.close();
				if(pstmt!=null) pstmt.close();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			
		}
	}
}
