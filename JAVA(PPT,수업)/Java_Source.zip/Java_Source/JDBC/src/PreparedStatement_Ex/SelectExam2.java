package PreparedStatement_Ex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SelectExam2 {

	public static void main(String[] args) {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		String sql = "Select * from member";
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"scott","123456");
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			System.out.println("    �й�         �̸�      �ּ�                ��ȭ��ȣ");
			System.out.println("--------------------------------------");
			while(rs.next()) {
				String hakbun = rs.getString("hakbun");
				String name = rs.getString("name");
				String addr = rs.getString("addr");
				String phone = rs.getString("phone");
				System.out.printf(" %5s  %4s    %4s     %15s\n",hakbun,name,addr,phone);
				/*
				 * ���� ������ ���
				  System.out.print("  "+rs.getString("hakbun")+"   ");
				  System.out.print(rs.getString("name")+"     ");
				  System.out.print(rs.getString("addr")+"       ");
				  System.out.print(rs.getString("phone")+"\n");
				*/
			}
		}
		catch(ClassNotFoundException cnfe) {
			System.out.println("Ŭ������ ã�� �� �����ϴ�."+cnfe.getMessage());
		}
		catch(SQLException se) {
			System.out.println(se.getMessage());
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				conn.close();
			}
			catch(Exception ignored) {
			}
			try {
				stmt.close();
			}
			catch(Exception ignored) {
			}
			try {
				rs.close();
			}
			catch(Exception ignored) {
			}
		}

	}

}
