package Statement_Ex;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCExample3 {
	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) {
		// ���� ��ǰ�ڵ带 �Է¹޾� �� ��ǰ�ڵ忡 �´� ���̺� ������ ���
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@127.0.0.1:1521:orcl","scott","123456");
			stmt = conn.createStatement();
			
			System.out.print("��ȸ�� ��ǰ�ڵ� �Է�=> ");
			String s_code = in.readLine();
			rs = stmt.executeQuery(
					"select code,name,price,maker from goodsinfo where code='"+s_code+"'");
			System.out.println("  ��ǰ�ڵ�            ��ǰ��\t   ����       ������");
			System.out.println("---------------------------------------");
			while(rs.next()) {
				String code = rs.getString("code");
				String name = rs.getString("name");
				int price = rs.getInt("price");
				String maker = rs.getString("maker");
				System.out.printf("%7s %10s %10d    %s\n",code,name,price,maker);
			}
		}
		catch(ClassNotFoundException cnfe) {
			System.out.println("�ش� Ŭ������ ã�� �� �����ϴ�."+cnfe.getMessage());
		}
		catch(SQLException se) {
			System.out.println(se.getMessage());
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				rs.close();
			}
			catch(Exception ignored) {
			}
			try {
				stmt.close();
			}
			catch(Exception ignored) {
			}
			try {
				conn.close();
			}
			catch(Exception ignored) {
			}
		}
	}
}
