package Statement_Ex;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DeleteExam {

	public static void main(String[] args) {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
		Connection conn = null;
		Statement stmt = null;
		BufferedReader in = null;
		
		try {
			in = new BufferedReader(new InputStreamReader(System.in));
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"scott","123456");
			stmt = conn.createStatement();
			System.out.println("Member���̺� �� �����ϱ�...");
			System.out.print("������ �й� �Է�: ");
			String del_hakbun = in.readLine();
			String sql = "delete from member where hakbun ='"+del_hakbun+"'";
			int row = stmt.executeUpdate(sql);
			if(row==1) {
				System.out.println(sql);
				System.out.println("���̺� ���� ���� ����!");
				
			}
		}
		catch(Exception e) {
			System.out.println("���� �߻�! : "+e.getMessage());
		}
		finally {
			try {
				conn.close();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			try {
				stmt.close();
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}

}
