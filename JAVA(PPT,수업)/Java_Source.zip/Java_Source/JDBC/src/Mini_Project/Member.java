/*
--ȸ�� ���� ���̺�
--ȸ����ȣ/ȸ���̸�/���Գ�¥/��ȭ��ȣ/�̸���/�ּ�/��üȽ��
create table book_member(
    membno varchar2(6) constraint book_member_membno_pk primary key,
    memname varchar2(6) constraint book_member_memname_nn not null,
    memdate date,
    phone varchar2(13) constraint book_member_phone_uk unique,
    email varchar2(16),
    addr varchar2(10),
    overdue number default 0
);
 */

package Mini_Project;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Member {
	Date memdate;
	String membno,memname,phone,email,addr;
	int overdue;
	SimpleDateFormat format1 = new SimpleDateFormat("YY/MM/dd");
	
	Member(){
	}
	
	void inputMember() {
		Scanner scan = new Scanner(System.in);
		System.out.print("ȸ���̸� �Է�=> ");
		memname = scan.next();
		System.out.print("��ȭ��ȣ �Է�=> ");
		phone = scan.next();
		System.out.print("�̸��� �Է�=> ");
		email = scan.next();
		System.out.print("�ּ� �Է�=> ");
		addr = scan.next();
	}
	
	void outputMember(){
		System.out.printf("%5s  %6s  %10s  %10s  %10s     %10s\t %d\n",
				membno,memname,format1.format(memdate),phone,email,addr,overdue);
	}
}
