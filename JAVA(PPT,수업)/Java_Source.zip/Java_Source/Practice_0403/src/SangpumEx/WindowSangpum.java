package SangpumEx;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class WindowSangpum {

	public static void main(String[] args) {
		JFrame frame = new JFrame("��ǰ ���� ���α׷�");
		frame.setPreferredSize(new Dimension(700,300));
		frame.setLocation(400,400);
		Container contentpane = frame.getContentPane();
		String colNames[] = {"��ǰ��ȣ","��ǰ��","����","�ܰ�","�ݾ�","���"};
		DefaultTableModel model = new DefaultTableModel(colNames,0);
		JTable table = new JTable(model);
		contentpane.add(new JScrollPane(table),BorderLayout.CENTER);
		
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		
		JTextField text1 = new JTextField(6);
		JTextField text2 = new JTextField(6);
		JTextField text3 = new JTextField(3);
		JTextField text4 = new JTextField(8);
		
		JLabel label1 = new JLabel("��ǰ��ȣ");
		JLabel label2 = new JLabel("��ǰ��");
		JLabel label3 = new JLabel("����");
		JLabel label4 = new JLabel("�ܰ�");
		
		JButton button1 = new JButton("�߰�");
		JButton button2 = new JButton("����");
		JButton button3 = new JButton("����");
		
		panel1.add(label1);
		panel1.add(text1);
		panel1.add(label2);
		panel1.add(text2);
		panel1.add(label3);
		panel1.add(text3);
		panel1.add(label4);
		panel1.add(text4);
		
		panel2.add(button1);
		panel2.add(button2);
		panel2.add(button3);
		
		panel3.setLayout(new BorderLayout());
		//JPanel panel3 = new JPanel(new BorderLayout());
		panel3.add(panel1,BorderLayout.CENTER);
		panel3.add(panel2,BorderLayout.SOUTH);
		contentpane.add(panel3,BorderLayout.SOUTH);
	
		button1.addActionListener(new ActionSangpum(table,text1,text2,text3,text4));
		button2.addActionListener(new ActionSangpum(table));
		button3.addActionListener(new ActionSangpum(table,text1,text2,text3,text4));
	
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}
