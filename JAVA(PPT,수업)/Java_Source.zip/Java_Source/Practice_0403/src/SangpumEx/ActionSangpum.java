package SangpumEx;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ActionSangpum implements ActionListener {
	JTable table;
	JTextField text1,text2,text3,text4;
	
	ActionSangpum(){
		
	}
	ActionSangpum(JTable table){
		this.table = table;
	}
	ActionSangpum(JTable table,JTextField text1,JTextField text2,
			JTextField text3,JTextField text4){
		this(table);
		this.text1 = text1;
		this.text2 = text2;
		this.text3 = text3;
		this.text4 = text4;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("�߰�")) {
			add();
		}else if(e.getActionCommand().equals("����")) {
			delete();
		}else {
			revise();
		}
	}
	
	void add() {
		Sangpum obj = new Sangpum();
		int i,rowNum,flag=0;
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		obj.code = text1.getText();
		rowNum = table.getRowCount();
		for(i=0;i<rowNum;i++) {
			String code01 = model.getValueAt(i,0).toString().trim();
			if(code01.equals(obj.code)) {
				flag=1;
				break;
			}
		}
		if(flag==0) {
			obj.name = text2.getText();
			obj.su = Integer.parseInt(text3.getText().toString());
			obj.price = Integer.parseInt(text4.getText().toString());
			obj.process();
			
			Object arr[] = new Object[6];
			arr[0] = obj.code;
			arr[1] = obj.name;
			arr[2] = obj.su;
			arr[3] = obj.price;
			arr[4] = obj.amount;
			arr[5] = obj.grade;
			
			model.addRow(arr);
			System.out.println("��ǰ ���� �Է� ����!!");
		}else {
			System.out.println("��ǰ ���� �Է� ����(�ߺ�)");
		}
		text1.setText("");
		text2.setText("");
		text3.setText("");
		text4.setText("");
	}
	
	void delete() {
		int row = table.getSelectedRow();
		if(row==-1)
			return;
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		model.removeRow(row);
		System.out.println("��ǰ ���� ���� ����!!");
	}
	
	void revise() {
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		Sangpum obj = new Sangpum();
		int rowNum = table.getRowCount();
		int i,flag=0;
		obj.code = text1.getText();
		obj.su = Integer.parseInt(text3.getText().toString());
		obj.price = Integer.parseInt(text4.getText().toString());
		for(i=0;i<rowNum;i++) {
			String code2 = table.getValueAt(i,0).toString();
			if(code2.equals(obj.code)) {
				obj.process();
				model.setValueAt(obj.su, i, 2);
				model.setValueAt(obj.price,i,3);
				model.setValueAt(obj.amount,i,4);
				model.setValueAt(obj.grade, i, 5);
				flag=1;
				break;
			}
		}
		if(flag==0) {
			System.out.println("������ ��ǰ�ڵ� �Է� ����!!");
		}else {
			System.out.println("��ǰ ���� ���� ����!!");
		}
		text1.setText("");
		text2.setText("");
		text3.setText("");
		text4.setText("");
	}
}
