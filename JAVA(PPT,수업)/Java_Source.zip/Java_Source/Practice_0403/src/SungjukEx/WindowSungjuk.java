package SungjukEx;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class WindowSungjuk {

	public static void main(String[] args) {
		//�⺻ ����
		JFrame frame = new JFrame("���� ���α׷�");
		frame.setPreferredSize(new Dimension(500,200));
		frame.setLocation(400,400);
		Container contentpane = frame.getContentPane();
		//����Ʈ ��
		String colNames[]= {"�й�","�̸�","����","����","����","����","���","���"};
		DefaultTableModel model = new DefaultTableModel(colNames,0);
		JTable table = new JTable(model);
		//��ũ���۾�
		contentpane.add(new JScrollPane(table),BorderLayout.CENTER);
		//�г��۾�
		JPanel panel = new JPanel();
		JTextField text1 = new JTextField(6);
		JTextField text2 = new JTextField(6);
		JTextField text3 = new JTextField(3);
		JTextField text4 = new JTextField(3);
		JTextField text5 = new JTextField(3);
		JLabel label1 = new JLabel("�й�");
		JLabel label2 = new JLabel("�̸�");
		JLabel label3 = new JLabel("����");
		JLabel label4 = new JLabel("����");
		JLabel label5 = new JLabel("����");
		JButton button1 = new JButton("�߰�");
		JButton button2 = new JButton("����");
		JButton button3 = new JButton("����");
		panel.add(label1);
		panel.add(text1);
		panel.add(label2);
		panel.add(text2);
		panel.add(label3);
		panel.add(text3);
		panel.add(label4);
		panel.add(text4);
		panel.add(label5);
		panel.add(text5);
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		panel.setPreferredSize(new Dimension(500,65));
		contentpane.add(panel,BorderLayout.SOUTH);
		button1.addActionListener(new EventAction(table,text1,text2,text3,text4,text5));
		button2.addActionListener(new EventAction(table));
		button3.addActionListener(new EventAction(table,text1,text2,text3,text4,text5));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}
