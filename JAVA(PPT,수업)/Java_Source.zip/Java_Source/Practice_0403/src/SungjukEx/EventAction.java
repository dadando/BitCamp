package SungjukEx;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class EventAction implements ActionListener {

	JTable table;
	JTextField text1,text2,text3,text4,text5;
	EventAction(JTable table){
		this.table = table;
	}
	
	EventAction(JTable table,JTextField text1,JTextField text2,
			JTextField text3,JTextField text4,JTextField text5){
		this.table = table;
		this.text1 = text1;
		this.text2 = text2;
		this.text3 = text3;
		this.text4 = text4;
		this.text5 = text5;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("�߰�")) {
			add();
		}
		else if(e.getActionCommand().equals("����")) {
			remove();
		}
		else if(e.getActionCommand().equals("����")) {
			revise();
		}
	}
	void add() {
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		Object arr[] = new Object[8];
		arr[0]= text1.getText();
		arr[1]= text2.getText();
		arr[2]= text3.getText();
		arr[3]= text4.getText();
		arr[4]= text5.getText();
		int kor = Integer.parseInt((String)arr[2]);
		int eng = Integer.parseInt((String)arr[3]);
		int math = Integer.parseInt((String)arr[4]);
		int tot = kor+eng+math;
		double avg = tot/3.;
		String grade;
		switch((int)avg/10) {
		case 10:
		case 9:
			grade = "��";
			break;
		case 8:
			grade = "��";
			break;
		case 7:
			grade = "��";
			break;
		case 6:
			grade = "��";
			break;
		default:
			grade = "��";
		}
		arr[5] = tot;
		arr[6] = avg;
		arr[7] = grade;
		
		
		model.addRow(arr);
		// �߰��� �ؽ�Ʈ���� ���.
		text1.setText("");
		text2.setText("");
		text3.setText("");
		text4.setText("");
		text5.setText("");
		System.out.println("�л� ���� �߰� ����!!!");
	}
	
	void remove() {
		int row = table.getSelectedRow();
		if(row == -1)
			// ���õ� ���̺��� ������ row�� -1.
			return;
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		model.removeRow(row);
		System.out.println("�л����� ���� ����!!!");
	}
	
	void revise() {
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		int rowNum = model.getRowCount();
		String hakbun = text1.getText();
		for(int row=0;row<rowNum;row++) {
			String rowName = (String) model.getValueAt(row,0);
			if(hakbun.equals(rowName)) {
				Object arr[] = new Object[8];
				arr[0]= model.getValueAt(row,0);
				arr[1]= model.getValueAt(row,1);
				arr[2]= text3.getText();
				arr[3]= text4.getText();
				arr[4]= text5.getText();
				
				int kor = Integer.parseInt(text3.getText());
				int eng = Integer.parseInt(text4.getText());
				int math = Integer.parseInt(text5.getText());
				int tot = kor+eng+math;
				double avg = tot/3.;
				String grade;
				switch((int)avg/10) {
				case 10:
				case 9:
					grade = "��";
					break;
				case 8:
					grade = "��";
					break;
				case 7:
					grade = "��";
					break;
				case 6:
					grade = "��";
					break;
				default:
					grade = "��";
				}
				arr[5] = tot;
				arr[6] = avg;
				arr[7] = grade;
				model.setValueAt(arr[2],row,2);
				model.setValueAt(arr[3],row,3);
				model.setValueAt(arr[4],row,4);
				model.setValueAt(arr[5],row,5);
				model.setValueAt(arr[6],row,6);
				model.setValueAt(arr[7],row,7);
				text1.setText("");
				text2.setText("");
				text3.setText("");
				text4.setText("");
				text5.setText("");
				System.out.println("�л� ���� ���� ����!!!");
			}
		}
	}
}
