package Practice_InterfaceEx;

public interface Datable {
	public abstract boolean inputData();
	public abstract void outputData();
}
