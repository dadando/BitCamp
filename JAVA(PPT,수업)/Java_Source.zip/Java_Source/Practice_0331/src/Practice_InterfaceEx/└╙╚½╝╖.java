package Practice_InterfaceEx;

public class ��ȫ�� {
	static final int MAX = 100;
	public static void main(String[] args) {
		Member obj1[] = new Member[MAX];
		Sawon obj2[] = new Sawon[MAX];
		
		int cnt1 = memberInput(obj1);
		int cnt2 = sawonInput(obj2);
		
		System.out.println("\t\t*** ȸ�� ���� ***");
		System.out.println("==============================================");
		System.out.println("�̸�\t����\t�̸���\t���̵�\t   �н�����");
		System.out.println("==============================================");
		printOut(obj1,cnt1);
		System.out.println("==============================================");
		System.out.printf("\t\t�� ȸ����: %d\n",cnt1);
		System.out.println();
		System.out.println("\t\t*** ��� ����***");
		System.out.println("==============================================");
		System.out.println("�����ȣ\t�μ���\t  �̸�\t  ����\t  �̸���");
		System.out.println("==============================================");
		printOut(obj2,cnt2);
		System.out.println("==============================================");
		System.out.printf("\t\t�� �����: %d",cnt2);
		
	}
	
	static int memberInput(Member obj[]) {
		int cnt=0;
		for(int i=0;i<MAX;i++) {
			obj[i] = new Member();
			if(obj[i].inputData()) {
				break;
			}
			cnt++;
			System.out.println();
		}
		return cnt;
	}
	static int sawonInput(Sawon obj[]) {
		int cnt=0;
		for(int i=0;i<MAX;i++) {
			obj[i] = new Sawon();
			if(obj[i].inputData()) 
				break;
			cnt++;
			System.out.println();
		}
		return cnt;
	}
	static void printOut(Datable obj[],int cnt) {
		for(int i=0;i<cnt;i++) {
			obj[i].outputData();
		}
	}
}
