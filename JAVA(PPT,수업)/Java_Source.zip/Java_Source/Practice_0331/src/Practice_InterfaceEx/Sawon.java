package Practice_InterfaceEx;

import java.util.Scanner;

public class Sawon extends Person implements Datable{
	String sabun,deptname;
	
	Sawon(){
		
	}
	
	public boolean inputData() {
		Scanner scan = new Scanner(System.in);
		System.out.print("�����ȣ �Է�=> ");
		sabun = scan.next();
		if(sabun.equals("exit"))
			return true;
		System.out.print("�μ��� �Է�=> ");
		deptname = scan.next();
		System.out.print("�̸� �Է�=> ");
		irum = scan.next();
		System.out.print("���� �Է�=> ");
		gender = scan.next();
		System.out.print("�̸��� �Է�=> ");
		email = scan.next();
		
		return false;
	}
	public void outputData() {
		System.out.printf("%4s   %5s   %3s   %6s %10s\n",sabun,deptname, irum, gender, email);
	}
	
}
