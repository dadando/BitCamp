package Practice_InterfaceEx;

public class Person {
	String irum;
	String gender;
	String email;
	Person(){
		
	}
}
