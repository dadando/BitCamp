package Practice_ClassEx;

import java.util.Scanner;

public class Member {
	String irum,gender,email,id,passwd;
	
	
	static int member_cnt = 0;
	
	
	Member(){
	}
	
	boolean inputData() {
		Scanner scan = new Scanner(System.in);
		System.out.print("�̸� �Է�=> ");
		irum = scan.next();
		if(irum.equals("exit")) {
			return true;
		}
		System.out.print("���� �Է�=> ");
		gender = scan.next();
		System.out.print("�̸��� �Է�=> ");
		email = scan.next();
		System.out.print("���̵� �Է�=> ");
		id = scan.next();
		System.out.print("�н����� �Է�=> ");
		passwd = scan.next();
		return false;
	}
	
	void outputData() {
		
		System.out.printf("%3s %6s %20s %10s %10s\n",irum,gender,email,id,passwd);
	}
	
	static int getMember_cnt() {
		return member_cnt;
	}
	
}
