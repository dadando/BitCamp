package Practice_ClassEx;

public class Sawon_Ex {
	static final int MAX =100;
	public static void main(String[] args) {
		Sawon obj[] = new Sawon[MAX];
		
		printIn(obj);
		printOut(obj);
		
	}
	static void printIn(Sawon obj[]) {
		for(int i=0;i<MAX;i++) {
			obj[i] = new Sawon();
			if(obj[i].inputData()) {
				return;
			}
		}
		System.out.println();
	}
	static void printOut(Sawon obj[]) {
		System.out.println("\t\t### ������� ###");
		System.out.println("===============================================");
		System.out.println("�����ȣ    �μ���   �̸�\t����                 �̸���   ");
		System.out.println("===============================================");
		for(int i=0;i<Sawon.getSawonCnt();i++) {
			obj[i].outputData();
		}
		System.out.println("===============================================");
		System.out.println("�� �����: "+Sawon.getSawonCnt());
	}

}
