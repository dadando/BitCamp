package Practice_ClassEx;

public class Example01 {
	
	static final int MAX = 100;
	
	public static void main(String[] args) {
		Member obj[] = new Member[MAX];
		int i;
		
		for(i=0;i<MAX;i++) {
			obj[i]= new Member();
			if(obj[i].inputData()) {
				break;
			}
			Member.member_cnt++;
			System.out.println();
		}
		printData(obj);
	}
	static void printData(Member obj[]) {
		System.out.println("\n\t*** ȸ������ ***");
		System.out.println("====================================================");
		System.out.println("�̸�    ����\t\t�̸���\t\t ���̵�         �н�����");
		int i;
		for(i=0;i<Member.member_cnt;i++) {
			obj[i].outputData();
		}
		System.out.println("====================================================");
		System.out.printf("\t\t�� ȸ���� : %d",Member.getMember_cnt());
	}
}
