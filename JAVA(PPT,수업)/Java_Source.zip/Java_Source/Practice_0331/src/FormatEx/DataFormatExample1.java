package FormatEx;

import java.util.*;
import java.text.*;
public class DataFormatExample1 {

	public static void main(String[] args) {
		GregorianCalendar calendar = new GregorianCalendar();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy�� MM�� dd�� mm�� ss��");
		String str = dateFormat.format(calendar.getTime());
		System.out.println(str);
			
	}

}
